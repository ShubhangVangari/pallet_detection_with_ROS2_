import cv2
import numpy as np

def preprocess_segmentation(image, target_size=(512, 512)):
    resized = cv2.resize(image, target_size)
    input_array = resized.astype(np.float32) / 255.0
    input_array = np.transpose(input_array, (2, 0, 1))  # HWC → CHW
    input_array = np.expand_dims(input_array, axis=0)
    return input_array

def apply_mask_overlay(output, original_image):
    raw_mask = output[0][0][0]
    resized_mask = cv2.resize(raw_mask, (original_image.shape[1], original_image.shape[0]))
    binary_mask = (resized_mask > 0.5).astype(np.uint8) * 255

    red_overlay = original_image.copy()
    red_overlay[binary_mask == 255] = [0, 0, 255]
    return cv2.addWeighted(original_image, 0.7, red_overlay, 0.3, 0)
