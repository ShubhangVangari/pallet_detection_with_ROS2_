import rclpy
from rclpy.node import Node

class PalletSegNode(Node):
    def __init__(self):
        super().__init__('pallet_seg_node')
        self.get_logger().info('Pallet Segmentation Node has started!')

def main(args=None):
    rclpy.init(args=args)
    node = PalletSegNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
