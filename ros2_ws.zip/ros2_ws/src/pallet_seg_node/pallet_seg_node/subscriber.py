import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import onnxruntime as ort
import numpy as np
import cv2
import os
from datetime import datetime

from pallet_seg_node.segmentation_helper import preprocess_segmentation, apply_mask_overlay
from pallet_seg_node.pallet_detector import PalletDetector


class InferenceSubscriber(Node):
    def __init__(self):
        super().__init__('inference_subscriber')
        self.get_logger().info('Starting inference subscriber...')

        self.subscription = self.create_subscription(Image, 'camera/image_raw', self.listener_callback, 10)
        self.bridge = CvBridge()

        # ROS publishers
        self.seg_pub = self.create_publisher(Image, '/ground_segmentation', 10)
        self.det_raw_pub = self.create_publisher(Image, '/pallet_detection_raw', 10)
        self.det_masked_pub = self.create_publisher(Image, '/pallet_detection_masked', 10)

        self.output_folder = '/home/shubbu/Documents/results'
        # os.makedirs(self.output_folder, exist_ok=True)

        seg_model_path = '/home/shubbu/Documents/onnx_models/segmentation_model.onnx'
        self.get_logger().info(f'Loading segmentation model from: {seg_model_path}')
        self.seg_session = ort.InferenceSession(seg_model_path)
        self.seg_input_name = self.seg_session.get_inputs()[0].name

        detector_model_path = '/home/shubbu/Documents/onnx_models/Fine_Tuning_TT_PD2_AMP_I_try_.onnx'
        self.get_logger().info(f'Loading pallet detector model from: {detector_model_path}')
        self.detector = PalletDetector(detector_model_path)

        self.get_logger().info('All models loaded successfully.')

    def listener_callback(self, msg):
        self.get_logger().info('Image received.')

        try:
            cv_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
            self.get_logger().info('Image converted using cv_bridge.')
        except Exception as e:
            self.get_logger().error(f'Failed to convert image: {e}')
            return

        seg_input = preprocess_segmentation(cv_image)
        seg_output = self.seg_session.run(None, {self.seg_input_name: seg_input})
        masked_image = apply_mask_overlay(seg_output, cv_image)

        self.seg_pub.publish(self.bridge.cv2_to_imgmsg(masked_image, encoding='bgr8'))
        self.get_logger().info('Published /ground_segmentation')

        det_on_raw = self.detector.run(cv_image)
        self.det_raw_pub.publish(self.bridge.cv2_to_imgmsg(det_on_raw, encoding='bgr8'))
        self.get_logger().info('Published /pallet_detection_raw')

        det_on_masked = self.detector.run(masked_image)
        self.det_masked_pub.publish(self.bridge.cv2_to_imgmsg(det_on_masked, encoding='bgr8'))
        self.get_logger().info('Published /pallet_detection_masked')

        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
        save_path = os.path.join(self.output_folder, f"output_{timestamp}.jpg")
        cv2.imwrite(save_path, det_on_masked)
        self.get_logger().info(f'Final result saved: {save_path}')


def main(args=None):
    rclpy.init(args=args)
    node = InferenceSubscriber()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()