import cv2
import numpy as np
import onnxruntime as ort

class PalletDetector:
    def __init__(self, model_path, input_size=640, conf_thres=0.25):
        self.model_path = model_path
        self.input_size = input_size
        self.conf_thres = conf_thres
        self.session = ort.InferenceSession(self.model_path)
        self.input_name = self.session.get_inputs()[0].name

    def preprocess(self, image):
        original = image.copy()
        resized = cv2.resize(image, (self.input_size, self.input_size))
        rgb = cv2.cvtColor(resized, cv2.COLOR_BGR2RGB)
        img = rgb.transpose(2, 0, 1).astype(np.float32) / 255.0
        img = np.expand_dims(img, axis=0)
        return img, original

    def postprocess(self, predictions, original):
        h, w, _ = original.shape
        preds = predictions[0]

        if preds.ndim == 3:
            preds = preds[0]

        for det in preds:
            if len(det) < 6:
                continue

            x1, y1, x2, y2, conf, cls = det[:6]

            if conf < self.conf_thres:
                continue

            # Scale box to original image
            x1 = int(x1 / self.input_size * w)
            y1 = int(y1 / self.input_size * h)
            x2 = int(x2 / self.input_size * w)
            y2 = int(y2 / self.input_size * h)

            cv2.rectangle(original, (x1, y1), (x2, y2), (0, 255, 0), 2)
            label = f"{int(cls)}: {conf:.2f}"
            cv2.putText(original, label, (x1, y1 - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)

        return original

    def run(self, image):
        input_tensor, original = self.preprocess(image)
        outputs = self.session.run(None, {self.input_name: input_tensor})
        image_with_boxes = self.postprocess(outputs, original)
        return image_with_boxes
