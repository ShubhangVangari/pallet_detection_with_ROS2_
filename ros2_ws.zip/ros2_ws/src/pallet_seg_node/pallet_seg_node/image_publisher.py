import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2
import os
import glob

class ImagePublisher(Node):
    def __init__(self):
        super().__init__('image_publisher')
        self.publisher_ = self.create_publisher(Image, 'camera/image_raw', 10)
        self.bridge = CvBridge()
        self.image_folder = '/home/shubbu/Documents/test_images' 
        self.image_files = sorted(glob.glob(os.path.join(self.image_folder, '*.jpg')))
        self.index = 0
        self.timer = self.create_timer(1.0, self.publish_image)

    def publish_image(self):
        if not self.image_files:
            self.get_logger().warn('No images found in folder!')
            return

        img_path = self.image_files[self.index]
        cv_img = cv2.imread(img_path)

        if cv_img is None:
            self.get_logger().warn(f'Could not read image: {img_path}')
        else:
            msg = self.bridge.cv2_to_imgmsg(cv_img, encoding="bgr8")
            self.publisher_.publish(msg)
            self.get_logger().info(f'Published: {os.path.basename(img_path)}')

        
        self.index = (self.index + 1) % len(self.image_files)


def main(args=None):
    rclpy.init(args=args)
    node = ImagePublisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
