from setuptools import setup

package_name = 'pallet_seg_node'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='shubbu',
    maintainer_email='your@email.com',
    description='Pallet detection and ground segmentation node',
    license='MIT',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'image_publisher = pallet_seg_node.image_publisher:main',
            'subscriber = pallet_seg_node.subscriber:main'
        ],
    },
)
